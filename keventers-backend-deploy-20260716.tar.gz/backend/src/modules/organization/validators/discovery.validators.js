import { z } from 'zod';

import { BANNER_PLACEMENT, BANNER_STATUS, BANNER_THEME } from '../models/banner.model.js';

/** Comma-separated list → trimmed string array (discovery query params). */
const csv = z
  .string()
  .transform((v) => v.split(',').map((s) => s.trim()).filter(Boolean))
  .optional();

export const discoveryQuerySchema = z.object({
  q: z.string().trim().max(120).optional(),
  lat: z.coerce.number().min(-90).max(90).optional(),
  lng: z.coerce.number().min(-180).max(180).optional(),
  radiusKm: z.coerce.number().positive().max(100).optional(),
  openNow: z.coerce.boolean().optional(),
  minRating: z.coerce.number().min(0).max(5).optional(),
  services: csv,
  cuisines: csv,
  sort: z.enum(['nearest', 'rating', 'popular', 'newest']).optional(),
  page: z.coerce.number().int().positive().optional(),
  limit: z.coerce.number().int().positive().max(50).optional(),
});

export const suggestQuerySchema = z.object({
  q: z.string().trim().max(120).default(''),
  lat: z.coerce.number().optional(),
  lng: z.coerce.number().optional(),
});

export const branchSlugParamSchema = z.object({
  slug: z.string().trim().min(1).max(80),
});

export const publicBannersQuerySchema = z.object({
  placement: z.enum(Object.values(BANNER_PLACEMENT)).optional(),
});

/* ── Admin banner CRUD ── */

const ctaSchema = z.object({
  label: z.string().trim().max(40).default(''),
  href: z.string().trim().max(300).default(''),
});

export const createBannerSchema = z.object({
  placement: z.enum(Object.values(BANNER_PLACEMENT)).optional(),
  title: z.string().trim().min(1).max(80),
  subtitle: z.string().trim().max(160).optional(),
  theme: z.enum(Object.values(BANNER_THEME)).optional(),
  imageUrl: z.string().url().max(500).nullish(),
  cta: ctaSchema.optional(),
  branchSlug: z.string().trim().max(80).nullish(),
  sortOrder: z.coerce.number().int().optional(),
  status: z.enum(Object.values(BANNER_STATUS)).optional(),
  startsAt: z.coerce.date().nullish(),
  endsAt: z.coerce.date().nullish(),
});

export const updateBannerSchema = createBannerSchema.partial();

export const listBannersQuerySchema = z.object({
  placement: z.enum(Object.values(BANNER_PLACEMENT)).optional(),
  status: z.enum(Object.values(BANNER_STATUS)).optional(),
  search: z.string().trim().max(120).optional(),
  sort: z.string().optional(),
  page: z.coerce.number().int().positive().optional(),
  limit: z.coerce.number().int().positive().max(100).optional(),
});
